package com.cscheerleader.recyclerviewexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class PersonActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_person);
    }
}
